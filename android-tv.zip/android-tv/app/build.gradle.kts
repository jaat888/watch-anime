plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Website address comes from gradle.properties (SITE_URL). Trailing slash is removed.
val siteUrl: String = (providers.gradleProperty("SITE_URL").orNull ?: "https://anime.blitz.cloud")
    .trim()
    .trimEnd('/')

android {
    namespace = "com.animetv.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.animetv.app"
        minSdk = 21          // Android 5.0 and up (covers old TVs)
        targetSdk = 27          // same as the Aptoide TV APK that installs fine on this TV
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "SITE_URL", "\"$siteUrl\"")
    }

    // A fixed debug key is committed (app/debug.keystore) so every build is signed
    // with the SAME key and a new APK can be installed over the old one.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
            enableV1Signing = true   // old TV firmwares need the classic JAR signature
            enableV2Signing = true
        }
    }

    buildTypes {
        getByName("debug") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    // Media3 1.3.x: still supports minSdk 21 and old TV chipsets.
    val media3 = "1.3.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-ui:$media3")
}
