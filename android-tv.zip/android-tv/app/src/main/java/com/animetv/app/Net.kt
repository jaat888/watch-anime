package com.animetv.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class ApiException(val status: Int, message: String) : Exception(message)

/** Tiny HTTP + JSON helper for the site's own API (no WebView involved). */
object Net {
    val main = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(4)
    private val imgPool = Executors.newFixedThreadPool(3)

    @Volatile
    var token: String? = null

    private const val UA = "Mozilla/5.0 (Linux; Android 7.0; TV) AnimeTV/1.0"

    /** Relative paths ("/img/s/x", "/mq/...") are resolved against the site address. */
    fun abs(path: String): String {
        if (path.startsWith("http://") || path.startsWith("https://")) return path
        return BuildConfig.SITE_URL + (if (path.startsWith("/")) "" else "/") + path
    }

    /** Blocking. GET when body == null, otherwise POST json. Call from a background thread. */
    fun request(path: String, body: JSONObject? = null): JSONObject {
        val c = URL(abs(path)).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept", "application/json")
            token?.let { c.setRequestProperty("Authorization", "Bearer $it") }
            if (body != null) {
                c.requestMethod = "POST"
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val json = try {
                JSONObject(text)
            } catch (e: Exception) {
                JSONObject()
            }
            if (code !in 200..299) throw ApiException(code, json.optString("error", "HTTP $code"))
            return json
        } finally {
            c.disconnect()
        }
    }

    /** Runs [work] on a background thread, then [ok] or [fail] on the UI thread. */
    fun <T> async(work: () -> T, ok: (T) -> Unit, fail: (Exception) -> Unit = {}) {
        pool.execute {
            try {
                val r = work()
                main.post { ok(r) }
            } catch (e: Exception) {
                main.post { fail(e) }
            }
        }
    }

    fun loadImage(iv: ImageView, url: String, targetW: Int) = Img.load(iv, url, targetW)

    internal fun submitImage(r: Runnable) = imgPool.execute(r)
}

object Img {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun load(iv: ImageView, url: String, targetW: Int, attempt: Int = 0) {
        iv.tag = url
        val hit = cache.get(url)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        if (attempt == 0) iv.setImageDrawable(null)
        if (url.isEmpty()) return
        Net.submitImage(Runnable {
            val bmp = try {
                download(url, targetW)
            } catch (e: Exception) {
                null
            }
            if (bmp != null) {
                cache.put(url, bmp)
                Net.main.post { if (iv.tag == url) iv.setImageBitmap(bmp) }
            } else if (attempt < 3) {
                // Server can be asleep for a few seconds (cold start) -> black poster forever.
                // Retry a few times with backoff instead of giving up after one failed try.
                Net.main.postDelayed({ if (iv.tag == url) load(iv, url, targetW, attempt + 1) }, 1200L * (attempt + 1))
            }
        })
    }

    private fun download(url: String, targetW: Int): Bitmap? {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 7.0; TV) AnimeTV/1.0")
            if (c.responseCode !in 200..299) return null
            val bytes = c.inputStream.use { it.readBytes() }
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            var sample = 1
            while (o.outWidth / (sample * 2) >= targetW) sample *= 2
            val o2 = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
        } finally {
            c.disconnect()
        }
    }
}
