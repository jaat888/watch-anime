# Anime TV (Android TV wrapper)

Full-screen WebView of the site + native Media3 ExoPlayer for video.

- **Site URL:** `gradle.properties` → `SITE_URL` (only place).
- **Build:** push to GitHub → Actions → "Build Android TV APK" → artifact `anime-tv-debug-apk`.
- **Signing:** `app/debug.keystore` (fixed debug key, so new APKs install over old ones).
- **Needs:** the modified `index.html` (uses `window.AndroidTV`) deployed on the site.

Remote in the player: OK = play/pause · Left/Right = ±10 s (hold = faster) ·
Up/Down = show controls, then volume · Back = close player.
